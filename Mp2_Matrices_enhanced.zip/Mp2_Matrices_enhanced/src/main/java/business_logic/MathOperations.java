/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business_logic;

import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import java.util.Arrays;

/**
 *
 * @author sydneyramgoolam
 */
public class MathOperations implements Matrices
{
    private Integer[][] A;// matrix A
    private Integer[][] B;// matrix B
    private Integer[][] C;// A + B xB, the resulting matrix

    //private String dummyValue = "dummy value";

    /*public String getDummyValue()
    {
        return dummyValue;
    }*/
    
    /**
     * Get the value of A
     *
     * @return the value of A
     */
    public Integer[][] getA() 
    {
        return A;
    }

    /**
     * Set the value of A
     *
     * @param A new value of A
     */
    public void setA(Integer[][] A)
    {
        this.A = A;
    }

    /**
     * Get the value of B
     *
     * @return the value of B
     */
    public Integer[][] getB()
    {
        return B;
    }

    /**
     * Set the value of B
     *
     * @param B new value of B
     */
    public void setB(Integer[][] B)
    {
        this.B = B;
    }

    /**
     * Get the value of C
     *
     * @return the value of C
     */
    public Integer[][] getC()
    {
        return C;
    }

    /**
     * Set the value of C
     *
     * @param C new value of C
     */
    public void setC(Integer[][] C)
    {
        this.C = C;
    }

    /**Adds two matrices and returns the result as a new matrices
     * 
     * @param m1 - matrix 1
     * @param m2 - matrix 2
     * @return - the addition of the two matrices.
     * @throws IllegalArgumentException if the sizes of m1, m2 are illegal for addition.
     */
    @Override
    public Integer[][] addMatrices(Integer[][] m1, Integer[][] m2) 
    {

        if (m1.length != m2.length || m1[0].length != m2[0].length)
        {
            FacesContext context = FacesContext.getCurrentInstance();
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_WARN, "Matrices cannot be Added: Illegal dimensions", "");
            context.addMessage(null, msg);
        }

        int rows = m1.length;
        int cols = m1[0].length;
        C = new Integer[rows][cols];

        //prints in the console
        System.out.println("Matrix A:");
        for (Integer[] row : m1) 
        {
            System.out.println(Arrays.toString(row));
        }
        
        //prints in the console
        System.out.println("Matrix B:");
        for (Integer[] row : m2)
        {
            System.out.println(Arrays.toString(row));
        }

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                C[i][j] = m1[i][j] + m2[i][j];
            }
        }

        //prints in the console
        System.out.println("Matrix C (Result):");
        for (Integer[] row : C)
        {
            System.out.println(Arrays.toString(row));
        }

        return C;
    }

    /**Multiples two matrices and returns the result as a new matrices
     * 
     * If m1 is 2x3 and m2 is 3x4 then the resulting matrix is 2x4
     * @param m1 - matrix 1
     * @param m2 - matrix 2
     * @return - the addition of the two matrices;
     * @throws IllegalArgumentException if the sizes of m1, m2 are illegal for multiplication.
     */
    @Override
    public Integer[][] multiplyMatrices(Integer[][] m1, Integer[][] m2) 
    {
        if (m1[0].length != m2.length)  
        {
            FacesContext context = FacesContext.getCurrentInstance();
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_WARN, "Matrices cannot be multiplied: illegal dimensions", "");
            context.addMessage(null, msg);
        }

        int rowsM1 = m1.length;
        int columnsM1 = m1[0].length;
        int columnsM2 = m2[0].length;

        C = new Integer[rowsM1][columnsM2];

        
        for (int i = 0; i < rowsM1; i++)
        {
            for (int j = 0; j < columnsM2; j++)
            {
                C[i][j] = 0; 
                for (int k = 0; k < columnsM1; k++)
                {
                    C[i][j] += m1[i][k] * m2[k][j];
                }
            }
        }
        return C;
    }
    
}
