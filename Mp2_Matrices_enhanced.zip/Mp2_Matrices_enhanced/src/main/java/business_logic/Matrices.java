/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package business_logic;

/**
 *
 * @author sydneyramgoolam
 */
public interface Matrices 
{
    /**Adds two matrices and returns the result as a new matrices
     * 
     * @param m1 - matrix 1
     * @param m2 - matrix 2
     * @return - the addition of the two matrices.
     * @throws IllegalArgumentException if the sizes of m1, m2 are illegal for addition.
     */
    public Integer[][] addMatrices(Integer[][] m1, Integer[][] m2);
    
    /**Multiples two matrices and returns the result as a new matrices
     * 
     * If m1 is 2x3 and m2 is 3x4 then the resulting matrix is 2x4
     * @param m1 - matrix 1
     * @param m2 - matrix 2
     * @return - the addition of the two matrices;
     * @throws IllegalArgumentException if the sizes of m1, m2 are illegal for multiplication.
     */
    public Integer[][] multiplyMatrices(Integer[][] m1, Integer[][] m2);
    
}
