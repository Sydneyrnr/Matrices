/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package beans;

import business_logic.MathOperations;
import business_logic.Matrices;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import java.io.Serializable;
import java.util.Arrays;

/**
 *
 * @author sydneyramgoolam
 */
@Named(value = "matricesBean")
@SessionScoped
public class MatricesBean implements Serializable 
{
    private Integer rowsA;
    private Integer columnsA;
    private Integer rowsB;
    private Integer columnsB;
    private MathOperations matrices= new MathOperations();

    
    public MatricesBean()
    {
        
    }
   
    /**
     * Get the value of rowsA
     *
     * @return the value of rowsA
     */
    public Integer getRowsA()
    {
        //System.out.println("getRowsA()");
        return rowsA;
    }

    /**
     * Set the value of rowsA
     *
     * @param rowsA new value of rowsA
     */
    public void setRowsA(Integer rowsA) 
    {
        System.out.println("setRowsA: " + rowsA);
        this.rowsA = rowsA;
    }

    /**
     * Get the value of columnsA
     *
     * @return the value of columnsA
     */
    public Integer getColumnsA()
    {
        //System.out.println("getColumnsA()");
        return columnsA;
    }

    /**
     * Set the value of columnsA
     *
     * @param columnsA new value of columnsA
     */
    public void setColumnsA(Integer columnsA) 
    {
        System.out.println("setColumnsA: " + columnsA);
        this.columnsA = columnsA;
    }

    /**
     * Get the value of rowsB
     *
     * @return the value of rowsB
     */
    public Integer getRowsB()
    {
        //System.out.println("getRowsB()");
        return rowsB;
    }

    /**
     * Set the value of rowsB
     *
     * @param rowsB new value of rowsB
     */
    public void setRowsB(Integer rowsB)
    {
        System.out.println("setRowsB: " + rowsB);
        this.rowsB = rowsB;
    }

    /**
     * Get the value of columnsB
     *
     * @return the value of columnsB
     */
    public Integer getColumnsB()
    {
        //System.out.println("getColumnsB()");
        return columnsB;
    }

    /**
     * Set the value of columnsB
     *
     * @param columnsB new value of columnsB
     */
    public void setColumnsB(Integer columnsB)
    {
        System.out.println("setColumnsB: " + columnsB);
        this.columnsB = columnsB;
    }
 
    public MathOperations getMatrices()
    {
        return matrices;
    }

    public void setMatrices(MathOperations matrices)
    {
        this.matrices = matrices;
    }

    public void createMatrices()
    {
        
        matrices.setA(new Integer[getRowsA()][getColumnsA()]);
        matrices.setB(new Integer[getRowsB()][getColumnsB()]);
        //System.out.println("Matrix A initialized with size: " + getRowsA() + "x" + getColumnsA());
        //System.out.println("Matrix B initialized with size: " + getRowsB() + "x" + getColumnsB());
        
    }
    
    public void addMatrices() {
    if (matrices.getA() != null && matrices.getB() != null) 
    {
        Integer[][] a = matrices.getA();
        Integer[][] b = matrices.getB();

      
        if (a.length == b.length && a[0].length == b[0].length)
        {
            System.out.println("Matrix A:");
            for (Integer[] row : a)
            {
                System.out.println(Arrays.toString(row));
            }

            System.out.println("Matrix B:");
            for (Integer[] row : b)
            {
                System.out.println(Arrays.toString(row));
            }

            matrices.setC(matrices.addMatrices(a, b));
            System.out.println("Matrix C (Result):");
            Integer[][] c = matrices.getC();

            for (Integer[] row : c)
            {
                System.out.println(Arrays.toString(row));
            }
        } 
        else 
        {
            
            FacesContext context = FacesContext.getCurrentInstance();
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_WARN, "Matrices cannot be added: Illegal dimensions", "");
            context.addMessage(null, msg);
            
            
            System.out.println("Matrices cannot be added: Illegal dimensions");
        }
    }
}
    
   public void multiplyMatrices()
   {
    if (matrices.getA() != null && matrices.getB() != null)
    {
        Integer[][] a = matrices.getA();
        Integer[][] b = matrices.getB();

        
        if (a[0].length == b.length) 
        {
            System.out.println("Matrix A:");
            for (Integer[] row : a) 
            {
                System.out.println(Arrays.toString(row));
            }

            System.out.println("Matrix B:");
            for (Integer[] row : b) 
            {
                System.out.println(Arrays.toString(row));
            }

            matrices.setC(matrices.multiplyMatrices(a, b)); 
            System.out.println("Matrix C (Result):");
            Integer[][] c = matrices.getC();

            for (Integer[] row : c)
            {
                System.out.println(Arrays.toString(row));
            }
        } 
        else
        {
            FacesContext context = FacesContext.getCurrentInstance();
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_WARN, "Matrices cannot be multiplied: Illegal dimensions", "");
            context.addMessage(null, msg);
            
            System.out.println("Matrices cannot be multiplied: Illegal dimensions");
        }
    }
    }
    
    public void clearMatrices() 
    {
        matrices.setA(null);
        matrices.setB(null);
        matrices.setC(null);
        setRowsA(null);
        setRowsB(null);
        setColumnsA(null);
        setColumnsB(null);
    }
    
}